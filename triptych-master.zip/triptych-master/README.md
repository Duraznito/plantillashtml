# triptych
don't look here
